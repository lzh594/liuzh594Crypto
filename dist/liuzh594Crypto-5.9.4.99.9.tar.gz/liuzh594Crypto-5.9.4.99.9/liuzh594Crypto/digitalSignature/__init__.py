# _*_ coding: utf-8 _*_
"""
Time:     2023/5/18 23:48
Author:   刘征昊(£·)
Version:  V 1.1
File:     __init__.py
Describe: 
"""

if __name__ == "__main__":
    pass
