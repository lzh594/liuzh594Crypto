# _*_ coding: utf-8 _*_
"""
Time:     2023/5/19 00:00
Author:   刘征昊(£·)
Version:  V 1.1
File:     __init__.py.py
Describe: 
"""

if __name__ == "__main__":
    pass
